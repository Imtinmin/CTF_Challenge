<?php
require 'includes/db.php';

session_start();
$action = $_GET['action'] ?? 'pages/index';
require $action . '.php';
