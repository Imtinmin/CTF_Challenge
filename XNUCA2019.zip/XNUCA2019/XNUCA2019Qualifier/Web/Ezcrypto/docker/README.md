docker build -t ezcrypto .
docker run -p 80:80 -d ezcrypto
flag:NeSE{mix_up1s-alittle^disgusting}