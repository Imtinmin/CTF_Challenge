<?php
	$content = file_get_contents('.htaccess');
    //include_once("fl3g.php"); 
    if(stristr($content,'on') || stristr($content,'html') || stristr($content,'type') || stristr($content,'flag') || stristr($content,'upload') || stristr($content,'file')) { 
        echo "Hacker"; 
        die(); 
    } 
    #var_dump(urlencode($content));
    var_dump(urlencode($content));