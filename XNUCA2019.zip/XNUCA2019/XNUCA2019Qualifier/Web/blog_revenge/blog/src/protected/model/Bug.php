<?php
class Bug extends Model{
	public $table_name = "bug";
}