<?php
class Note extends Model{
	public $table_name = "note";
}