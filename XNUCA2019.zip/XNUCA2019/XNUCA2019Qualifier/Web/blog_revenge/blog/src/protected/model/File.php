<?php
class File extends Model{
	public $table_name = "file";
}