注意修改`docker-compose.yml`文件中的几个环境变量，根据注释设置服务器的地址以及flag。
