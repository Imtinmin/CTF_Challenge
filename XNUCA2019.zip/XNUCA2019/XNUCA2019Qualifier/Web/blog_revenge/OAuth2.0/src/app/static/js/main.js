layui.use('form', function(){
    var form = layui.form;
});

layui.use('element', function(){
    var element = layui.element;
    
});


        