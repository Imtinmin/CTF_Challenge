
#include <stdio.h>
#include<strings.h>
int main(int argc, char **argv)
{
    int fin = 0;
    char flag[71] ;//flag{this_is-a_naive_but_hard_obfuscated_program_compiled_by_Llvm_pasS};
    bzero(flag, 71);
    scanf("%s", flag);

 // f-l-a
    if(flag[0]*flag[0]*flag[0] - (flag[0]*flag[0])*(307) + flag[0]*(31386) - 1068552 !=0 || flag[2]*flag[2]*flag[2] - (flag[2]*flag[2])*(307) + flag[2]*(31386) - 1068552 !=0 || flag[1]*flag[1]*flag[1] - (flag[1]*flag[1])*(307) + flag[1]*(31386) - 1068552 != 0)
        {
            // printf("f:l:a\n");
            fin |= 1;
        }
    else if(flag[0] == flag[1] || flag[1] == flag[2] || flag[2]==flag[0]){
            fin |= 1;
     }
        fin ^= 0;

 // l-a-g
    if(flag[1]*flag[1]*flag[1] - (flag[1]*flag[1])*(308) + flag[1]*(31591) - 1079028 !=0 || flag[3]*flag[3]*flag[3] - (flag[3]*flag[3])*(308) + flag[3]*(31591) - 1079028 !=0 || flag[2]*flag[2]*flag[2] - (flag[2]*flag[2])*(308) + flag[2]*(31591) - 1079028 != 0)
        {
            // printf("l:a:g\n");
            fin |= 1;
        }
    else if(flag[1] == flag[2] || flag[2] == flag[3] || flag[3]==flag[1]){
            fin |= 1;
     }
        fin ^= 0;

 // a-g-{
    if(flag[2]*flag[2]*flag[2] - (flag[2]*flag[2])*(323) + flag[2]*(34591) - 1228893 !=0 || flag[4]*flag[4]*flag[4] - (flag[4]*flag[4])*(323) + flag[4]*(34591) - 1228893 !=0 || flag[3]*flag[3]*flag[3] - (flag[3]*flag[3])*(323) + flag[3]*(34591) - 1228893 != 0)
        {
            // printf("a:g:{\n");
            fin |= 1;
        }
    else if(flag[2] == flag[3] || flag[3] == flag[4] || flag[4]==flag[2]){
            fin |= 1;
     }
        fin ^= 0;

 // g-{-t
    if(flag[3]*flag[3]*flag[3] - (flag[3]*flag[3])*(342) + flag[3]*(38885) - 1469604 !=0 || flag[5]*flag[5]*flag[5] - (flag[5]*flag[5])*(342) + flag[5]*(38885) - 1469604 !=0 || flag[4]*flag[4]*flag[4] - (flag[4]*flag[4])*(342) + flag[4]*(38885) - 1469604 != 0)
        {
            // printf("g:{:t\n");
            fin |= 1;
        }
    else if(flag[3] == flag[4] || flag[4] == flag[5] || flag[5]==flag[3]){
            fin |= 1;
     }
        fin ^= 0;

 // {-t-h
    if(flag[4]*flag[4]*flag[4] - (flag[4]*flag[4])*(343) + flag[4]*(39124) - 1483872 !=0 || flag[6]*flag[6]*flag[6] - (flag[6]*flag[6])*(343) + flag[6]*(39124) - 1483872 !=0 || flag[5]*flag[5]*flag[5] - (flag[5]*flag[5])*(343) + flag[5]*(39124) - 1483872 != 0)
        {
            // printf("{:t:h\n");
            fin |= 1;
        }
    else if(flag[4] == flag[5] || flag[5] == flag[6] || flag[6]==flag[4]){
            fin |= 1;
     }
        fin ^= 0;

 // t-h-i
    if(flag[5]*flag[5]*flag[5] - (flag[5]*flag[5])*(325) + flag[5]*(35164) - 1266720 !=0 || flag[7]*flag[7]*flag[7] - (flag[7]*flag[7])*(325) + flag[7]*(35164) - 1266720 !=0 || flag[6]*flag[6]*flag[6] - (flag[6]*flag[6])*(325) + flag[6]*(35164) - 1266720 != 0)
        {
            // printf("t:h:i\n");
            fin |= 1;
        }
    else if(flag[5] == flag[6] || flag[6] == flag[7] || flag[7]==flag[5]){
            fin |= 1;
     }
        fin ^= 0;

 // h-i-s
    if(flag[6]*flag[6]*flag[6] - (flag[6]*flag[6])*(324) + flag[6]*(34955) - 1255800 !=0 || flag[8]*flag[8]*flag[8] - (flag[8]*flag[8])*(324) + flag[8]*(34955) - 1255800 !=0 || flag[7]*flag[7]*flag[7] - (flag[7]*flag[7])*(324) + flag[7]*(34955) - 1255800 != 0)
        {
            // printf("h:i:s\n");
            fin |= 1;
        }
    else if(flag[6] == flag[7] || flag[7] == flag[8] || flag[8]==flag[6]){
            fin |= 1;
     }
        fin ^= 0;

 // i-s-_
    if(flag[7]*flag[7]*flag[7] - (flag[7]*flag[7])*(315) + flag[7]*(32975) - 1147125 !=0 || flag[9]*flag[9]*flag[9] - (flag[9]*flag[9])*(315) + flag[9]*(32975) - 1147125 !=0 || flag[8]*flag[8]*flag[8] - (flag[8]*flag[8])*(315) + flag[8]*(32975) - 1147125 != 0)
        {
            // printf("i:s:_\n");
            fin |= 1;
        }
    else if(flag[7] == flag[8] || flag[8] == flag[9] || flag[9]==flag[7]){
            fin |= 1;
     }
        fin ^= 0;

 // s-_-i
    if(flag[8]*flag[8]*flag[8] - (flag[8]*flag[8])*(315) + flag[8]*(32975) - 1147125 !=0 || flag[10]*flag[10]*flag[10] - (flag[10]*flag[10])*(315) + flag[10]*(32975) - 1147125 !=0 || flag[9]*flag[9]*flag[9] - (flag[9]*flag[9])*(315) + flag[9]*(32975) - 1147125 != 0)
        {
            // printf("s:_:i\n");
            fin |= 1;
        }
    else if(flag[8] == flag[9] || flag[9] == flag[10] || flag[10]==flag[8]){
            fin |= 1;
     }
        fin ^= 0;

 // _-i-s
    if(flag[9]*flag[9]*flag[9] - (flag[9]*flag[9])*(315) + flag[9]*(32975) - 1147125 !=0 || flag[11]*flag[11]*flag[11] - (flag[11]*flag[11])*(315) + flag[11]*(32975) - 1147125 !=0 || flag[10]*flag[10]*flag[10] - (flag[10]*flag[10])*(315) + flag[10]*(32975) - 1147125 != 0)
        {
            // printf("_:i:s\n");
            fin |= 1;
        }
    else if(flag[9] == flag[10] || flag[10] == flag[11] || flag[11]==flag[9]){
            fin |= 1;
     }
        fin ^= 0;

 // i-s--
    if(flag[10]*flag[10]*flag[10] - (flag[10]*flag[10])*(265) + flag[10]*(21975) - 543375 !=0 || flag[12]*flag[12]*flag[12] - (flag[12]*flag[12])*(265) + flag[12]*(21975) - 543375 !=0 || flag[11]*flag[11]*flag[11] - (flag[11]*flag[11])*(265) + flag[11]*(21975) - 543375 != 0)
        {
            // printf("i:s:-\n");
            fin |= 1;
        }
    else if(flag[10] == flag[11] || flag[11] == flag[12] || flag[12]==flag[10]){
            fin |= 1;
     }
        fin ^= 0;

 // s---a
    if(flag[11]*flag[11]*flag[11] - (flag[11]*flag[11])*(257) + flag[11]*(20695) - 501975 !=0 || flag[13]*flag[13]*flag[13] - (flag[13]*flag[13])*(257) + flag[13]*(20695) - 501975 !=0 || flag[12]*flag[12]*flag[12] - (flag[12]*flag[12])*(257) + flag[12]*(20695) - 501975 != 0)
        {
            // printf("s:-:a\n");
            fin |= 1;
        }
    else if(flag[11] == flag[12] || flag[12] == flag[13] || flag[13]==flag[11]){
            fin |= 1;
     }
        fin ^= 0;

 // --a-_
    if(flag[12]*flag[12]*flag[12] - (flag[12]*flag[12])*(237) + flag[12]*(17855) - 414675 !=0 || flag[14]*flag[14]*flag[14] - (flag[14]*flag[14])*(237) + flag[14]*(17855) - 414675 !=0 || flag[13]*flag[13]*flag[13] - (flag[13]*flag[13])*(237) + flag[13]*(17855) - 414675 != 0)
        {
            // printf("-:a:_\n");
            fin |= 1;
        }
    else if(flag[12] == flag[13] || flag[13] == flag[14] || flag[14]==flag[12]){
            fin |= 1;
     }
        fin ^= 0;

 // a-_-n
    if(flag[13]*flag[13]*flag[13] - (flag[13]*flag[13])*(302) + flag[13]*(30335) - 1013650 !=0 || flag[15]*flag[15]*flag[15] - (flag[15]*flag[15])*(302) + flag[15]*(30335) - 1013650 !=0 || flag[14]*flag[14]*flag[14] - (flag[14]*flag[14])*(302) + flag[14]*(30335) - 1013650 != 0)
        {
            // printf("a:_:n\n");
            fin |= 1;
        }
    else if(flag[13] == flag[14] || flag[14] == flag[15] || flag[15]==flag[13]){
            fin |= 1;
     }
        fin ^= 0;

 // _-n-a
    if(flag[14]*flag[14]*flag[14] - (flag[14]*flag[14])*(302) + flag[14]*(30335) - 1013650 !=0 || flag[16]*flag[16]*flag[16] - (flag[16]*flag[16])*(302) + flag[16]*(30335) - 1013650 !=0 || flag[15]*flag[15]*flag[15] - (flag[15]*flag[15])*(302) + flag[15]*(30335) - 1013650 != 0)
        {
            // printf("_:n:a\n");
            fin |= 1;
        }
    else if(flag[14] == flag[15] || flag[15] == flag[16] || flag[16]==flag[14]){
            fin |= 1;
     }
        fin ^= 0;

 // n-a-i
    if(flag[15]*flag[15]*flag[15] - (flag[15]*flag[15])*(312) + flag[15]*(32405) - 1120350 !=0 || flag[17]*flag[17]*flag[17] - (flag[17]*flag[17])*(312) + flag[17]*(32405) - 1120350 !=0 || flag[16]*flag[16]*flag[16] - (flag[16]*flag[16])*(312) + flag[16]*(32405) - 1120350 != 0)
        {
            // printf("n:a:i\n");
            fin |= 1;
        }
    else if(flag[15] == flag[16] || flag[16] == flag[17] || flag[17]==flag[15]){
            fin |= 1;
     }
        fin ^= 0;

 // a-i-v
    if(flag[16]*flag[16]*flag[16] - (flag[16]*flag[16])*(320) + flag[16]*(34021) - 1201830 !=0 || flag[18]*flag[18]*flag[18] - (flag[18]*flag[18])*(320) + flag[18]*(34021) - 1201830 !=0 || flag[17]*flag[17]*flag[17] - (flag[17]*flag[17])*(320) + flag[17]*(34021) - 1201830 != 0)
        {
            // printf("a:i:v\n");
            fin |= 1;
        }
    else if(flag[16] == flag[17] || flag[17] == flag[18] || flag[18]==flag[16]){
            fin |= 1;
     }
        fin ^= 0;

 // i-v-e
    if(flag[17]*flag[17]*flag[17] - (flag[17]*flag[17])*(324) + flag[17]*(34913) - 1251390 !=0 || flag[19]*flag[19]*flag[19] - (flag[19]*flag[19])*(324) + flag[19]*(34913) - 1251390 !=0 || flag[18]*flag[18]*flag[18] - (flag[18]*flag[18])*(324) + flag[18]*(34913) - 1251390 != 0)
        {
            // printf("i:v:e\n");
            fin |= 1;
        }
    else if(flag[17] == flag[18] || flag[18] == flag[19] || flag[19]==flag[17]){
            fin |= 1;
     }
        fin ^= 0;

 // v-e-_
    if(flag[18]*flag[18]*flag[18] - (flag[18]*flag[18])*(314) + flag[18]*(32723) - 1132210 !=0 || flag[20]*flag[20]*flag[20] - (flag[20]*flag[20])*(314) + flag[20]*(32723) - 1132210 !=0 || flag[19]*flag[19]*flag[19] - (flag[19]*flag[19])*(314) + flag[19]*(32723) - 1132210 != 0)
        {
            // printf("v:e:_\n");
            fin |= 1;
        }
    else if(flag[18] == flag[19] || flag[19] == flag[20] || flag[20]==flag[18]){
            fin |= 1;
     }
        fin ^= 0;

 // e-_-b
    if(flag[19]*flag[19]*flag[19] - (flag[19]*flag[19])*(294) + flag[19]*(28803) - 940310 !=0 || flag[21]*flag[21]*flag[21] - (flag[21]*flag[21])*(294) + flag[21]*(28803) - 940310 !=0 || flag[20]*flag[20]*flag[20] - (flag[20]*flag[20])*(294) + flag[20]*(28803) - 940310 != 0)
        {
            // printf("e:_:b\n");
            fin |= 1;
        }
    else if(flag[19] == flag[20] || flag[20] == flag[21] || flag[21]==flag[19]){
            fin |= 1;
     }
        fin ^= 0;

 // _-b-u
    if(flag[20]*flag[20]*flag[20] - (flag[20]*flag[20])*(310) + flag[20]*(31891) - 1089270 !=0 || flag[22]*flag[22]*flag[22] - (flag[22]*flag[22])*(310) + flag[22]*(31891) - 1089270 !=0 || flag[21]*flag[21]*flag[21] - (flag[21]*flag[21])*(310) + flag[21]*(31891) - 1089270 != 0)
        {
            // printf("_:b:u\n");
            fin |= 1;
        }
    else if(flag[20] == flag[21] || flag[21] == flag[22] || flag[22]==flag[20]){
            fin |= 1;
     }
        fin ^= 0;

 // b-u-t
    if(flag[21]*flag[21]*flag[21] - (flag[21]*flag[21])*(331) + flag[21]*(36406) - 1330056 !=0 || flag[23]*flag[23]*flag[23] - (flag[23]*flag[23])*(331) + flag[23]*(36406) - 1330056 !=0 || flag[22]*flag[22]*flag[22] - (flag[22]*flag[22])*(331) + flag[22]*(36406) - 1330056 != 0)
        {
            // printf("b:u:t\n");
            fin |= 1;
        }
    else if(flag[21] == flag[22] || flag[22] == flag[23] || flag[23]==flag[21]){
            fin |= 1;
     }
        fin ^= 0;

 // u-t-_
    if(flag[22]*flag[22]*flag[22] - (flag[22]*flag[22])*(328) + flag[22]*(35707) - 1289340 !=0 || flag[24]*flag[24]*flag[24] - (flag[24]*flag[24])*(328) + flag[24]*(35707) - 1289340 !=0 || flag[23]*flag[23]*flag[23] - (flag[23]*flag[23])*(328) + flag[23]*(35707) - 1289340 != 0)
        {
            // printf("u:t:_\n");
            fin |= 1;
        }
    else if(flag[22] == flag[23] || flag[23] == flag[24] || flag[24]==flag[22]){
            fin |= 1;
     }
        fin ^= 0;

 // t-_-h
    if(flag[23]*flag[23]*flag[23] - (flag[23]*flag[23])*(315) + flag[23]*(32964) - 1146080 !=0 || flag[25]*flag[25]*flag[25] - (flag[25]*flag[25])*(315) + flag[25]*(32964) - 1146080 !=0 || flag[24]*flag[24]*flag[24] - (flag[24]*flag[24])*(315) + flag[24]*(32964) - 1146080 != 0)
        {
            // printf("t:_:h\n");
            fin |= 1;
        }
    else if(flag[23] == flag[24] || flag[24] == flag[25] || flag[25]==flag[23]){
            fin |= 1;
     }
        fin ^= 0;

 // _-h-a
    if(flag[24]*flag[24]*flag[24] - (flag[24]*flag[24])*(296) + flag[24]*(29183) - 958360 !=0 || flag[26]*flag[26]*flag[26] - (flag[26]*flag[26])*(296) + flag[26]*(29183) - 958360 !=0 || flag[25]*flag[25]*flag[25] - (flag[25]*flag[25])*(296) + flag[25]*(29183) - 958360 != 0)
        {
            // printf("_:h:a\n");
            fin |= 1;
        }
    else if(flag[24] == flag[25] || flag[25] == flag[26] || flag[26]==flag[24]){
            fin |= 1;
     }
        fin ^= 0;

 // h-a-r
    if(flag[25]*flag[25]*flag[25] - (flag[25]*flag[25])*(315) + flag[25]*(33002) - 1150032 !=0 || flag[27]*flag[27]*flag[27] - (flag[27]*flag[27])*(315) + flag[27]*(33002) - 1150032 !=0 || flag[26]*flag[26]*flag[26] - (flag[26]*flag[26])*(315) + flag[26]*(33002) - 1150032 != 0)
        {
            // printf("h:a:r\n");
            fin |= 1;
        }
    else if(flag[25] == flag[26] || flag[26] == flag[27] || flag[27]==flag[25]){
            fin |= 1;
     }
        fin ^= 0;

 // a-r-d
    if(flag[26]*flag[26]*flag[26] - (flag[26]*flag[26])*(311) + flag[26]*(32158) - 1105800 !=0 || flag[28]*flag[28]*flag[28] - (flag[28]*flag[28])*(311) + flag[28]*(32158) - 1105800 !=0 || flag[27]*flag[27]*flag[27] - (flag[27]*flag[27])*(311) + flag[27]*(32158) - 1105800 != 0)
        {
            // printf("a:r:d\n");
            fin |= 1;
        }
    else if(flag[26] == flag[27] || flag[27] == flag[28] || flag[28]==flag[26]){
            fin |= 1;
     }
        fin ^= 0;

 // r-d-_
    if(flag[27]*flag[27]*flag[27] - (flag[27]*flag[27])*(309) + flag[27]*(31730) - 1083000 !=0 || flag[29]*flag[29]*flag[29] - (flag[29]*flag[29])*(309) + flag[29]*(31730) - 1083000 !=0 || flag[28]*flag[28]*flag[28] - (flag[28]*flag[28])*(309) + flag[28]*(31730) - 1083000 != 0)
        {
            // printf("r:d:_\n");
            fin |= 1;
        }
    else if(flag[27] == flag[28] || flag[28] == flag[29] || flag[29]==flag[27]){
            fin |= 1;
     }
        fin ^= 0;

 // d-_-o
    if(flag[28]*flag[28]*flag[28] - (flag[28]*flag[28])*(306) + flag[28]*(31145) - 1054500 !=0 || flag[30]*flag[30]*flag[30] - (flag[30]*flag[30])*(306) + flag[30]*(31145) - 1054500 !=0 || flag[29]*flag[29]*flag[29] - (flag[29]*flag[29])*(306) + flag[29]*(31145) - 1054500 != 0)
        {
            // printf("d:_:o\n");
            fin |= 1;
        }
    else if(flag[28] == flag[29] || flag[29] == flag[30] || flag[30]==flag[28]){
            fin |= 1;
     }
        fin ^= 0;

 // _-o-b
    if(flag[29]*flag[29]*flag[29] - (flag[29]*flag[29])*(304) + flag[29]*(30733) - 1033410 !=0 || flag[31]*flag[31]*flag[31] - (flag[31]*flag[31])*(304) + flag[31]*(30733) - 1033410 !=0 || flag[30]*flag[30]*flag[30] - (flag[30]*flag[30])*(304) + flag[30]*(30733) - 1033410 != 0)
        {
            // printf("_:o:b\n");
            fin |= 1;
        }
    else if(flag[29] == flag[30] || flag[30] == flag[31] || flag[31]==flag[29]){
            fin |= 1;
     }
        fin ^= 0;

 // o-b-f
    if(flag[30]*flag[30]*flag[30] - (flag[30]*flag[30])*(311) + flag[30]*(32196) - 1109556 !=0 || flag[32]*flag[32]*flag[32] - (flag[32]*flag[32])*(311) + flag[32]*(32196) - 1109556 !=0 || flag[31]*flag[31]*flag[31] - (flag[31]*flag[31])*(311) + flag[31]*(32196) - 1109556 != 0)
        {
            // printf("o:b:f\n");
            fin |= 1;
        }
    else if(flag[30] == flag[31] || flag[31] == flag[32] || flag[32]==flag[30]){
            fin |= 1;
     }
        fin ^= 0;

 // b-f-u
    if(flag[31]*flag[31]*flag[31] - (flag[31]*flag[31])*(317) + flag[31]*(33396) - 1169532 !=0 || flag[33]*flag[33]*flag[33] - (flag[33]*flag[33])*(317) + flag[33]*(33396) - 1169532 !=0 || flag[32]*flag[32]*flag[32] - (flag[32]*flag[32])*(317) + flag[32]*(33396) - 1169532 != 0)
        {
            // printf("b:f:u\n");
            fin |= 1;
        }
    else if(flag[31] == flag[32] || flag[32] == flag[33] || flag[33]==flag[31]){
            fin |= 1;
     }
        fin ^= 0;

 // f-u-s
    if(flag[32]*flag[32]*flag[32] - (flag[32]*flag[32])*(334) + flag[32]*(37119) - 1372410 !=0 || flag[34]*flag[34]*flag[34] - (flag[34]*flag[34])*(334) + flag[34]*(37119) - 1372410 !=0 || flag[33]*flag[33]*flag[33] - (flag[33]*flag[33])*(334) + flag[33]*(37119) - 1372410 != 0)
        {
            // printf("f:u:s\n");
            fin |= 1;
        }
    else if(flag[32] == flag[33] || flag[33] == flag[34] || flag[34]==flag[32]){
            fin |= 1;
     }
        fin ^= 0;

 // u-s-c
    if(flag[33]*flag[33]*flag[33] - (flag[33]*flag[33])*(331) + flag[33]*(36423) - 1332045 !=0 || flag[35]*flag[35]*flag[35] - (flag[35]*flag[35])*(331) + flag[35]*(36423) - 1332045 !=0 || flag[34]*flag[34]*flag[34] - (flag[34]*flag[34])*(331) + flag[34]*(36423) - 1332045 != 0)
        {
            // printf("u:s:c\n");
            fin |= 1;
        }
    else if(flag[33] == flag[34] || flag[34] == flag[35] || flag[35]==flag[33]){
            fin |= 1;
     }
        fin ^= 0;

 // s-c-a
    if(flag[34]*flag[34]*flag[34] - (flag[34]*flag[34])*(311) + flag[34]*(32143) - 1104345 !=0 || flag[36]*flag[36]*flag[36] - (flag[36]*flag[36])*(311) + flag[36]*(32143) - 1104345 !=0 || flag[35]*flag[35]*flag[35] - (flag[35]*flag[35])*(311) + flag[35]*(32143) - 1104345 != 0)
        {
            // printf("s:c:a\n");
            fin |= 1;
        }
    else if(flag[34] == flag[35] || flag[35] == flag[36] || flag[36]==flag[34]){
            fin |= 1;
     }
        fin ^= 0;

 // c-a-t
    if(flag[35]*flag[35]*flag[35] - (flag[35]*flag[35])*(312) + flag[35]*(32339) - 1113948 !=0 || flag[37]*flag[37]*flag[37] - (flag[37]*flag[37])*(312) + flag[37]*(32339) - 1113948 !=0 || flag[36]*flag[36]*flag[36] - (flag[36]*flag[36])*(312) + flag[36]*(32339) - 1113948 != 0)
        {
            // printf("c:a:t\n");
            fin |= 1;
        }
    else if(flag[35] == flag[36] || flag[36] == flag[37] || flag[37]==flag[35]){
            fin |= 1;
     }
        fin ^= 0;

 // a-t-e
    if(flag[36]*flag[36]*flag[36] - (flag[36]*flag[36])*(314) + flag[36]*(32765) - 1136452 !=0 || flag[38]*flag[38]*flag[38] - (flag[38]*flag[38])*(314) + flag[38]*(32765) - 1136452 !=0 || flag[37]*flag[37]*flag[37] - (flag[37]*flag[37])*(314) + flag[37]*(32765) - 1136452 != 0)
        {
            // printf("a:t:e\n");
            fin |= 1;
        }
    else if(flag[36] == flag[37] || flag[37] == flag[38] || flag[38]==flag[36]){
            fin |= 1;
     }
        fin ^= 0;

 // t-e-d
    if(flag[37]*flag[37]*flag[37] - (flag[37]*flag[37])*(317) + flag[37]*(33416) - 1171600 !=0 || flag[39]*flag[39]*flag[39] - (flag[39]*flag[39])*(317) + flag[39]*(33416) - 1171600 !=0 || flag[38]*flag[38]*flag[38] - (flag[38]*flag[38])*(317) + flag[38]*(33416) - 1171600 != 0)
        {
            // printf("t:e:d\n");
            fin |= 1;
        }
    else if(flag[37] == flag[38] || flag[38] == flag[39] || flag[39]==flag[37]){
            fin |= 1;
     }
        fin ^= 0;

 // e-d-_
    if(flag[38]*flag[38]*flag[38] - (flag[38]*flag[38])*(296) + flag[38]*(29195) - 959500 !=0 || flag[40]*flag[40]*flag[40] - (flag[40]*flag[40])*(296) + flag[40]*(29195) - 959500 !=0 || flag[39]*flag[39]*flag[39] - (flag[39]*flag[39])*(296) + flag[39]*(29195) - 959500 != 0)
        {
            // printf("e:d:_\n");
            fin |= 1;
        }
    else if(flag[38] == flag[39] || flag[39] == flag[40] || flag[40]==flag[38]){
            fin |= 1;
     }
        fin ^= 0;

 // d-_-p
    if(flag[39]*flag[39]*flag[39] - (flag[39]*flag[39])*(307) + flag[39]*(31340) - 1064000 !=0 || flag[41]*flag[41]*flag[41] - (flag[41]*flag[41])*(307) + flag[41]*(31340) - 1064000 !=0 || flag[40]*flag[40]*flag[40] - (flag[40]*flag[40])*(307) + flag[40]*(31340) - 1064000 != 0)
        {
            // printf("d:_:p\n");
            fin |= 1;
        }
    else if(flag[39] == flag[40] || flag[40] == flag[41] || flag[41]==flag[39]){
            fin |= 1;
     }
        fin ^= 0;

 // _-p-r
    if(flag[40]*flag[40]*flag[40] - (flag[40]*flag[40])*(321) + flag[40]*(34238) - 1212960 !=0 || flag[42]*flag[42]*flag[42] - (flag[42]*flag[42])*(321) + flag[42]*(34238) - 1212960 !=0 || flag[41]*flag[41]*flag[41] - (flag[41]*flag[41])*(321) + flag[41]*(34238) - 1212960 != 0)
        {
            // printf("_:p:r\n");
            fin |= 1;
        }
    else if(flag[40] == flag[41] || flag[41] == flag[42] || flag[42]==flag[40]){
            fin |= 1;
     }
        fin ^= 0;

 // p-r-o
    if(flag[41]*flag[41]*flag[41] - (flag[41]*flag[41])*(337) + flag[41]*(37854) - 1417248 !=0 || flag[43]*flag[43]*flag[43] - (flag[43]*flag[43])*(337) + flag[43]*(37854) - 1417248 !=0 || flag[42]*flag[42]*flag[42] - (flag[42]*flag[42])*(337) + flag[42]*(37854) - 1417248 != 0)
        {
            // printf("p:r:o\n");
            fin |= 1;
        }
    else if(flag[41] == flag[42] || flag[42] == flag[43] || flag[43]==flag[41]){
            fin |= 1;
     }
        fin ^= 0;

 // r-o-g
    if(flag[42]*flag[42]*flag[42] - (flag[42]*flag[42])*(328) + flag[42]*(35829) - 1303362 !=0 || flag[44]*flag[44]*flag[44] - (flag[44]*flag[44])*(328) + flag[44]*(35829) - 1303362 !=0 || flag[43]*flag[43]*flag[43] - (flag[43]*flag[43])*(328) + flag[43]*(35829) - 1303362 != 0)
        {
            // printf("r:o:g\n");
            fin |= 1;
        }
    else if(flag[42] == flag[43] || flag[43] == flag[44] || flag[44]==flag[42]){
            fin |= 1;
     }
        fin ^= 0;

 // o-g-r
    if(flag[43]*flag[43]*flag[43] - (flag[43]*flag[43])*(328) + flag[43]*(35829) - 1303362 !=0 || flag[45]*flag[45]*flag[45] - (flag[45]*flag[45])*(328) + flag[45]*(35829) - 1303362 !=0 || flag[44]*flag[44]*flag[44] - (flag[44]*flag[44])*(328) + flag[44]*(35829) - 1303362 != 0)
        {
            // printf("o:g:r\n");
            fin |= 1;
        }
    else if(flag[43] == flag[44] || flag[44] == flag[45] || flag[45]==flag[43]){
            fin |= 1;
     }
        fin ^= 0;

 // g-r-a
    if(flag[44]*flag[44]*flag[44] - (flag[44]*flag[44])*(314) + flag[44]*(32791) - 1138974 !=0 || flag[46]*flag[46]*flag[46] - (flag[46]*flag[46])*(314) + flag[46]*(32791) - 1138974 !=0 || flag[45]*flag[45]*flag[45] - (flag[45]*flag[45])*(314) + flag[45]*(32791) - 1138974 != 0)
        {
            // printf("g:r:a\n");
            fin |= 1;
        }
    else if(flag[44] == flag[45] || flag[45] == flag[46] || flag[46]==flag[44]){
            fin |= 1;
     }
        fin ^= 0;

 // r-a-m
    if(flag[45]*flag[45]*flag[45] - (flag[45]*flag[45])*(320) + flag[45]*(34057) - 1205322 !=0 || flag[47]*flag[47]*flag[47] - (flag[47]*flag[47])*(320) + flag[47]*(34057) - 1205322 !=0 || flag[46]*flag[46]*flag[46] - (flag[46]*flag[46])*(320) + flag[46]*(34057) - 1205322 != 0)
        {
            // printf("r:a:m\n");
            fin |= 1;
        }
    else if(flag[45] == flag[46] || flag[46] == flag[47] || flag[47]==flag[45]){
            fin |= 1;
     }
        fin ^= 0;

 // a-m-_
    if(flag[46]*flag[46]*flag[46] - (flag[46]*flag[46])*(301) + flag[46]*(30143) - 1004435 !=0 || flag[48]*flag[48]*flag[48] - (flag[48]*flag[48])*(301) + flag[48]*(30143) - 1004435 !=0 || flag[47]*flag[47]*flag[47] - (flag[47]*flag[47])*(301) + flag[47]*(30143) - 1004435 != 0)
        {
            // printf("a:m:_\n");
            fin |= 1;
        }
    else if(flag[46] == flag[47] || flag[47] == flag[48] || flag[48]==flag[46]){
            fin |= 1;
     }
        fin ^= 0;

 // m-_-c
    if(flag[47]*flag[47]*flag[47] - (flag[47]*flag[47])*(303) + flag[47]*(30551) - 1025145 !=0 || flag[49]*flag[49]*flag[49] - (flag[49]*flag[49])*(303) + flag[49]*(30551) - 1025145 !=0 || flag[48]*flag[48]*flag[48] - (flag[48]*flag[48])*(303) + flag[48]*(30551) - 1025145 != 0)
        {
            // printf("m:_:c\n");
            fin |= 1;
        }
    else if(flag[47] == flag[48] || flag[48] == flag[49] || flag[49]==flag[47]){
            fin |= 1;
     }
        fin ^= 0;

 // _-c-o
    if(flag[48]*flag[48]*flag[48] - (flag[48]*flag[48])*(305) + flag[48]*(30939) - 1043955 !=0 || flag[50]*flag[50]*flag[50] - (flag[50]*flag[50])*(305) + flag[50]*(30939) - 1043955 !=0 || flag[49]*flag[49]*flag[49] - (flag[49]*flag[49])*(305) + flag[49]*(30939) - 1043955 != 0)
        {
            // printf("_:c:o\n");
            fin |= 1;
        }
    else if(flag[48] == flag[49] || flag[49] == flag[50] || flag[50]==flag[48]){
            fin |= 1;
     }
        fin ^= 0;

 // c-o-m
    if(flag[49]*flag[49]*flag[49] - (flag[49]*flag[49])*(319) + flag[49]*(33879) - 1197801 !=0 || flag[51]*flag[51]*flag[51] - (flag[51]*flag[51])*(319) + flag[51]*(33879) - 1197801 !=0 || flag[50]*flag[50]*flag[50] - (flag[50]*flag[50])*(319) + flag[50]*(33879) - 1197801 != 0)
        {
            // printf("c:o:m\n");
            fin |= 1;
        }
    else if(flag[49] == flag[50] || flag[50] == flag[51] || flag[51]==flag[49]){
            fin |= 1;
     }
        fin ^= 0;

 // o-m-p
    if(flag[50]*flag[50]*flag[50] - (flag[50]*flag[50])*(332) + flag[50]*(36739) - 1355088 !=0 || flag[52]*flag[52]*flag[52] - (flag[52]*flag[52])*(332) + flag[52]*(36739) - 1355088 !=0 || flag[51]*flag[51]*flag[51] - (flag[51]*flag[51])*(332) + flag[51]*(36739) - 1355088 != 0)
        {
            // printf("o:m:p\n");
            fin |= 1;
        }
    else if(flag[50] == flag[51] || flag[51] == flag[52] || flag[52]==flag[50]){
            fin |= 1;
     }
        fin ^= 0;

 // m-p-i
    if(flag[51]*flag[51]*flag[51] - (flag[51]*flag[51])*(326) + flag[51]*(35413) - 1281840 !=0 || flag[53]*flag[53]*flag[53] - (flag[53]*flag[53])*(326) + flag[53]*(35413) - 1281840 !=0 || flag[52]*flag[52]*flag[52] - (flag[52]*flag[52])*(326) + flag[52]*(35413) - 1281840 != 0)
        {
            // printf("m:p:i\n");
            fin |= 1;
        }
    else if(flag[51] == flag[52] || flag[52] == flag[53] || flag[53]==flag[51]){
            fin |= 1;
     }
        fin ^= 0;

 // p-i-l
    if(flag[52]*flag[52]*flag[52] - (flag[52]*flag[52])*(325) + flag[52]*(35196) - 1270080 !=0 || flag[54]*flag[54]*flag[54] - (flag[54]*flag[54])*(325) + flag[54]*(35196) - 1270080 !=0 || flag[53]*flag[53]*flag[53] - (flag[53]*flag[53])*(325) + flag[53]*(35196) - 1270080 != 0)
        {
            // printf("p:i:l\n");
            fin |= 1;
        }
    else if(flag[52] == flag[53] || flag[53] == flag[54] || flag[54]==flag[52]){
            fin |= 1;
     }
        fin ^= 0;

 // i-l-e
    if(flag[53]*flag[53]*flag[53] - (flag[53]*flag[53])*(314) + flag[53]*(32853) - 1145340 !=0 || flag[55]*flag[55]*flag[55] - (flag[55]*flag[55])*(314) + flag[55]*(32853) - 1145340 !=0 || flag[54]*flag[54]*flag[54] - (flag[54]*flag[54])*(314) + flag[54]*(32853) - 1145340 != 0)
        {
            // printf("i:l:e\n");
            fin |= 1;
        }
    else if(flag[53] == flag[54] || flag[54] == flag[55] || flag[55]==flag[53]){
            fin |= 1;
     }
        fin ^= 0;

 // l-e-d
    if(flag[54]*flag[54]*flag[54] - (flag[54]*flag[54])*(309) + flag[54]*(31808) - 1090800 !=0 || flag[56]*flag[56]*flag[56] - (flag[56]*flag[56])*(309) + flag[56]*(31808) - 1090800 !=0 || flag[55]*flag[55]*flag[55] - (flag[55]*flag[55])*(309) + flag[55]*(31808) - 1090800 != 0)
        {
            // printf("l:e:d\n");
            fin |= 1;
        }
    else if(flag[54] == flag[55] || flag[55] == flag[56] || flag[56]==flag[54]){
            fin |= 1;
     }
        fin ^= 0;

 // e-d-_
    if(flag[55]*flag[55]*flag[55] - (flag[55]*flag[55])*(296) + flag[55]*(29195) - 959500 !=0 || flag[57]*flag[57]*flag[57] - (flag[57]*flag[57])*(296) + flag[57]*(29195) - 959500 !=0 || flag[56]*flag[56]*flag[56] - (flag[56]*flag[56])*(296) + flag[56]*(29195) - 959500 != 0)
        {
            // printf("e:d:_\n");
            fin |= 1;
        }
    else if(flag[55] == flag[56] || flag[56] == flag[57] || flag[57]==flag[55]){
            fin |= 1;
     }
        fin ^= 0;

 // d-_-b
    if(flag[56]*flag[56]*flag[56] - (flag[56]*flag[56])*(293) + flag[56]*(28610) - 931000 !=0 || flag[58]*flag[58]*flag[58] - (flag[58]*flag[58])*(293) + flag[58]*(28610) - 931000 !=0 || flag[57]*flag[57]*flag[57] - (flag[57]*flag[57])*(293) + flag[57]*(28610) - 931000 != 0)
        {
            // printf("d:_:b\n");
            fin |= 1;
        }
    else if(flag[56] == flag[57] || flag[57] == flag[58] || flag[58]==flag[56]){
            fin |= 1;
     }
        fin ^= 0;

 // _-b-y
    if(flag[57]*flag[57]*flag[57] - (flag[57]*flag[57])*(314) + flag[57]*(32663) - 1126510 !=0 || flag[59]*flag[59]*flag[59] - (flag[59]*flag[59])*(314) + flag[59]*(32663) - 1126510 !=0 || flag[58]*flag[58]*flag[58] - (flag[58]*flag[58])*(314) + flag[58]*(32663) - 1126510 != 0)
        {
            // printf("_:b:y\n");
            fin |= 1;
        }
    else if(flag[57] == flag[58] || flag[58] == flag[59] || flag[59]==flag[57]){
            fin |= 1;
     }
        fin ^= 0;

 // b-y-_
    if(flag[58]*flag[58]*flag[58] - (flag[58]*flag[58])*(314) + flag[58]*(32663) - 1126510 !=0 || flag[60]*flag[60]*flag[60] - (flag[60]*flag[60])*(314) + flag[60]*(32663) - 1126510 !=0 || flag[59]*flag[59]*flag[59] - (flag[59]*flag[59])*(314) + flag[59]*(32663) - 1126510 != 0)
        {
            // printf("b:y:_\n");
            fin |= 1;
        }
    else if(flag[58] == flag[59] || flag[59] == flag[60] || flag[60]==flag[58]){
            fin |= 1;
     }
        fin ^= 0;

 // y-_-L
    if(flag[59]*flag[59]*flag[59] - (flag[59]*flag[59])*(292) + flag[59]*(27911) - 873620 !=0 || flag[61]*flag[61]*flag[61] - (flag[61]*flag[61])*(292) + flag[61]*(27911) - 873620 !=0 || flag[60]*flag[60]*flag[60] - (flag[60]*flag[60])*(292) + flag[60]*(27911) - 873620 != 0)
        {
            // printf("y:_:L\n");
            fin |= 1;
        }
    else if(flag[59] == flag[60] || flag[60] == flag[61] || flag[61]==flag[59]){
            fin |= 1;
     }
        fin ^= 0;

 // _-L-l
    if(flag[60]*flag[60]*flag[60] - (flag[60]*flag[60])*(279) + flag[60]*(25688) - 779760 !=0 || flag[62]*flag[62]*flag[62] - (flag[62]*flag[62])*(279) + flag[62]*(25688) - 779760 !=0 || flag[61]*flag[61]*flag[61] - (flag[61]*flag[61])*(279) + flag[61]*(25688) - 779760 != 0)
        {
            // printf("_:L:l\n");
            fin |= 1;
        }
    else if(flag[60] == flag[61] || flag[61] == flag[62] || flag[62]==flag[60]){
            fin |= 1;
     }
        fin ^= 0;

 // L-l-v
    if(flag[61]*flag[61]*flag[61] - (flag[61]*flag[61])*(302) + flag[61]*(29920) - 968544 !=0 || flag[63]*flag[63]*flag[63] - (flag[63]*flag[63])*(302) + flag[63]*(29920) - 968544 !=0 || flag[62]*flag[62]*flag[62] - (flag[62]*flag[62])*(302) + flag[62]*(29920) - 968544 != 0)
        {
            // printf("L:l:v\n");
            fin |= 1;
        }
    else if(flag[61] == flag[62] || flag[62] == flag[63] || flag[63]==flag[61]){
            fin |= 1;
     }
        fin ^= 0;

 // l-v-m
    if(flag[62]*flag[62]*flag[62] - (flag[62]*flag[62])*(335) + flag[62]*(37378) - 1389096 !=0 || flag[64]*flag[64]*flag[64] - (flag[64]*flag[64])*(335) + flag[64]*(37378) - 1389096 !=0 || flag[63]*flag[63]*flag[63] - (flag[63]*flag[63])*(335) + flag[63]*(37378) - 1389096 != 0)
        {
            // printf("l:v:m\n");
            fin |= 1;
        }
    else if(flag[62] == flag[63] || flag[63] == flag[64] || flag[64]==flag[62]){
            fin |= 1;
     }
        fin ^= 0;

 // v-m-_
    if(flag[63]*flag[63]*flag[63] - (flag[63]*flag[63])*(322) + flag[63]*(34427) - 1221890 !=0 || flag[65]*flag[65]*flag[65] - (flag[65]*flag[65])*(322) + flag[65]*(34427) - 1221890 !=0 || flag[64]*flag[64]*flag[64] - (flag[64]*flag[64])*(322) + flag[64]*(34427) - 1221890 != 0)
        {
            // printf("v:m:_\n");
            fin |= 1;
        }
    else if(flag[63] == flag[64] || flag[64] == flag[65] || flag[65]==flag[63]){
            fin |= 1;
     }
        fin ^= 0;

 // m-_-p
    if(flag[64]*flag[64]*flag[64] - (flag[64]*flag[64])*(316) + flag[64]*(33203) - 1159760 !=0 || flag[66]*flag[66]*flag[66] - (flag[66]*flag[66])*(316) + flag[66]*(33203) - 1159760 !=0 || flag[65]*flag[65]*flag[65] - (flag[65]*flag[65])*(316) + flag[65]*(33203) - 1159760 != 0)
        {
            // printf("m:_:p\n");
            fin |= 1;
        }
    else if(flag[64] == flag[65] || flag[65] == flag[66] || flag[66]==flag[64]){
            fin |= 1;
     }
        fin ^= 0;

 // _-p-a
    if(flag[65]*flag[65]*flag[65] - (flag[65]*flag[65])*(304) + flag[65]*(30719) - 1032080 !=0 || flag[67]*flag[67]*flag[67] - (flag[67]*flag[67])*(304) + flag[67]*(30719) - 1032080 !=0 || flag[66]*flag[66]*flag[66] - (flag[66]*flag[66])*(304) + flag[66]*(30719) - 1032080 != 0)
        {
            // printf("_:p:a\n");
            fin |= 1;
        }
    else if(flag[65] == flag[66] || flag[66] == flag[67] || flag[67]==flag[65]){
            fin |= 1;
     }
        fin ^= 0;

 // p-a-s
    if(flag[66]*flag[66]*flag[66] - (flag[66]*flag[66])*(324) + flag[66]*(34899) - 1249360 !=0 || flag[68]*flag[68]*flag[68] - (flag[68]*flag[68])*(324) + flag[68]*(34899) - 1249360 !=0 || flag[67]*flag[67]*flag[67] - (flag[67]*flag[67])*(324) + flag[67]*(34899) - 1249360 != 0)
        {
            // printf("p:a:s\n");
            fin |= 1;
        }
    else if(flag[66] == flag[67] || flag[67] == flag[68] || flag[68]==flag[66]){
            fin |= 1;
     }
        fin ^= 0;

 // a-s-S
    if(flag[67]*flag[67]*flag[67] - (flag[67]*flag[67])*(295) + flag[67]*(28751) - 925865 !=0 || flag[69]*flag[69]*flag[69] - (flag[69]*flag[69])*(295) + flag[69]*(28751) - 925865 !=0 || flag[68]*flag[68]*flag[68] - (flag[68]*flag[68])*(295) + flag[68]*(28751) - 925865 != 0)
        {
            // printf("a:s:S\n");
            fin |= 1;
        }
    else if(flag[67] == flag[68] || flag[68] == flag[69] || flag[69]==flag[67]){
            fin |= 1;
     }
        fin ^= 0;

 // s-S-}
    if(flag[68]*flag[68]*flag[68] - (flag[68]*flag[68])*(323) + flag[68]*(34295) - 1193125 !=0 || flag[70]*flag[70]*flag[70] - (flag[70]*flag[70])*(323) + flag[70]*(34295) - 1193125 !=0 || flag[69]*flag[69]*flag[69] - (flag[69]*flag[69])*(323) + flag[69]*(34295) - 1193125 != 0)
        {
            // printf("s:S:}\n");
            fin |= 1;
        }
    else if(flag[68] == flag[69] || flag[69] == flag[70] || flag[70]==flag[68]){
            fin |= 1;
     }
        fin ^= 0;
   if(fin==0)
   puts("Success!");
   else
   puts("Failure!");
    return 0;
}

