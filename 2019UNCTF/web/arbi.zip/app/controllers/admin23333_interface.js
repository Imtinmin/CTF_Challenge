const fs = require("fs");
module.exports = function(req,res){
    if(req.session.username !== "admin"){
        return res.send("U Are N0t Admin")
    }
    if(req.query.name === undefined){
        return res.sendStatus(500)
    }
    else if(typeof(req.query.name) === "string"){
      
        if(req.query.name.startsWith('{') && req.query.name.endsWith('}')){
            req.query.name = JSON.parse(req.query.name)
    
            if(!/^key$/im.test(req.query.name.filename))return res.sendStatus(500);
            
    
           
        }
    }
    var filename = ""

    if(req.query.name.filename.length > 3){
        for(let c of req.query.name.filename){
            if(c !== "/" && c!=="."){
                filename += c
            }
        }
    }
    
    console.log(filename)
    
    var content = fs.readFileSync("/etc/"+filename)
    res.send(content)
    
    
  }
