module.exports = function(req,res){
    
    if(req.session.username === undefined){
        return res.redirect("/login");
    }
    var imgsrc = "/uri?src=http://127.0.0.1:9000/upload/"+req.session.username+".jpg";

    return res.render("home",{
            "username":req.session.username,
            "src":imgsrc,
        }
    )
}