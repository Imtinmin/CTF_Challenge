const jwt = require("jsonwebtoken");


module.exports = function(req,res){
    var username = req.body.username;
    var password = req.body.password;
    
    if(req.body.username === undefined || req.body.password === undefined ){
        return res.status(500).json({"error":"username undefined"}).end();
    }
    if(req.body.username === "" ){
        return res.status(500).json({"error":"username is blank"}).end();
    }

    try {
        var id = JSON.parse(Buffer.from((req.cookies.token.split(".")[1]),"base64").toString()).id;
    } catch (error) {
        return res.status(500).json({"error":"something wrong"}).end();
    }


    var secret = global.secretlist[id];

    try {
        var user = jwt.verify(req.cookies.token,secret,{algorithm: "HS256"});
    } catch (error) {
        return res.status(500).json({"error":"jwt error"}).end();
    }

    if(user.username === username && user.password === password){
        req.session.username = username;
        return res.redirect("/home");
    }
    else{
        return res.status(500).json({"error":"pass error"}).end();
    }
}