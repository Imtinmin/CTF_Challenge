module.exports = function(req,res){
    if (res.cookie.auth === undefined){
        return res.redirect("/login")
    }
    else{
        return res.redirect("/home")
    }
}