const jwt = require("jsonwebtoken")
const crypto = require('crypto');
const fs = require("fs")
module.exports = function(req,res){
    if(global.secretlist.length > 10000){
        global.secretlist = []
    }
    if(req.body.username === undefined  || req.body.username==="admin"){
        return res.status(500).json({"error":"can't reg admin or 'blank'"}).end();
    }
    var username = req.body.username;
    var password = req.body.password;
    //设置头像
    
    try {
        fs.accessSync("upload/"+username+".jpg")
    } catch (error) {
        fs.writeFileSync("upload/"+username+".jpg", fs.readFileSync("upload/paidaxing.jpg"));      
    }


    var secret = crypto.randomBytes(18).toString("hex");
    var id = global.secretlist.length;
    global.secretlist.push(secret)
    var token = {"id":id,"username":username,"password":password}
    token = jwt.sign(token,secret,{algorithm: "HS256"})
    res.cookie("token",token)
    return res.send("reg success!<script>setTimeout(()=>{window.location='/login'},1000)</script>")
    
}