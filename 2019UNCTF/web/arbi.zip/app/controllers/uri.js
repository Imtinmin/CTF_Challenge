const axios = require('axios');


module.exports = function(req,res){
    var src = req.query.src;
    var username = req.session.username;
    

    if(src.slice(29).slice(0,-4) !== username){
        return res.status(500).json({"error":"Evil request!"}).end();
    }
    axios.get(src,{
        timeout: 1500,
        responseType: 'arraybuffer'
    })
        .then(function(response){
            if(response.status === 200){
                res.set("Content-Type","image/jpg");
                return res.send(response.data);
            }
            else{
                return reject();
            }
        })
        .catch(function(mesaage){
            return res.status(500).json({"error":"request error 404 or others"}).end();
        })



}