const express = require("express");
const routers = require("./routers/index");
const app = express();
var cookieParser = require('cookie-parser'); 
const session = require('express-session');
var FileStore = require('session-file-store')(session);
const crypto = require("crypto");

app.engine('jade' ,require('jade').__express);
app.set("view engine","jade");
app.set('views', __dirname+'/views');


app.use(express.urlencoded({ extended: false }));
app.use('/upload', express.static('upload'))

app.use(cookieParser()); 

var sessionOpts = {
    // 设置密钥
    store: new FileStore,
    secret: crypto.randomBytes(36).toString("hex"),
    // secret: crypto.randomBytes(36).toString("hex"),
    // Forces the session to be saved back to the session store
    resave: true,
    // Forces a session that is "uninitialized" to be saved to the store.
    saveUninitialized: true,
    
    key: 'session',
    // If secure is set to true, and you access your site over HTTP, the cookie will not be set.
    cookie: { maxAge: 365 * 24 * 60 * 60 * 1000, secure: false }
   }
app.use(session(sessionOpts))

app.use("/",routers)



app.listen(3000, () => {
    
    global.secretlist = [];
})