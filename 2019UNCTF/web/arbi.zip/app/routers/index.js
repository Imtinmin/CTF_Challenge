const express = require('express');

const indexController = require("../controllers/index");
const loginController = require("../controllers/login");
const regController = require("../controllers/reg");
const homeControler = require("../controllers/home");
const uriControler = require("../controllers/uri");
const adminController = require("../controllers/admin23333_interface")
const routers = express.Router();

// wwwbackup
routers.get('/VerYs3cretWwWb4ck4p33441122.zip',(req,res)=>{
    return res.sendFile(__dirname+"/www.zip")
});

routers.get('/',indexController);

routers.get('/login',(req,res)=>{res.render("login")});
routers.post('/login',loginController);

routers.get('/reg',(req,res)=>{res.render("reg")});
routers.post('/reg',regController);

routers.get('/home',homeControler);
routers.get('/uri',uriControler);

routers.get('/admin23333_interface',adminController);
routers.use(function (err, req, res, next) {
    
    return res.status(500).json({error: "sorry, something wrong"});
});
module.exports = routers
