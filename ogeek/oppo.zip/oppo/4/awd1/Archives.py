content3 = "Hello,World!"

content2 = """
前端是真的麻烦
"""

content1="""
线代真麻烦，写个脚本计算两个向量的点积，将就着用。
"""

Archives = {1: {'title': 'TODO', 'content': content1},
            2: {'title': 'flask开发初体验', 'content': content2},
            3: {'title': '搜索真不好写', 'content': content3}
            }