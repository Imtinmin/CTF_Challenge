<?php

echo Bootstrap::pageTitle(array('title'=>$L->g('About'), 'icon'=>'info-circle'));

echo '
<table class="table table-striped mt-3">
	<tbody>
';

echo '<tr>';
echo '<td>Zero Edition</td>';
if (defined('Zero_PRO')) {
	echo '<td>PRO - '.$L->g('Thanks for supporting Zero').' <span class="fa fa-heart" style="color: #ffc107"></span></td>';
} else {
	echo '<td>Standard - <a target="_blank" href="https://pro.Zero.com">'.$L->g('Upgrade to Zero PRO').'</a></td>';
}
echo '</tr>';

echo '<tr>';
echo '<td>Zero Version</td>';
echo '<td>'.Zero_VERSION.'</td>';
echo '</tr>';

echo '<tr>';
echo '<td>Zero Codename</td>';
echo '<td>'.Zero_CODENAME.'</td>';
echo '</tr>';

echo '<tr>';
echo '<td>Zero Build Number</td>';
echo '<td>'.Zero_BUILD.'</td>';
echo '</tr>';

echo '<tr>';
echo '<td><a href="'.HTML_PATH_ADMIN_ROOT.'developers'.'">Zero Developers</a></td>';
echo '<td></td>';
echo '</tr>';

echo '
	</tbody>
</table>
';
