<?php defined('Zero') or die('Zero CMS.'); ?>
{
    "position": 1,
    "robotstxt": "User-agent: *\r\nAllow: \/"
}