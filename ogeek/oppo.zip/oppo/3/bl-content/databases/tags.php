<?php defined('Zero') or die('Zero CMS.'); ?>
{
    "Zero": {
        "name": "Zero",
        "description": "",
        "template": "",
        "list": [
            "follow-Zero"
        ]
    },
    "cms": {
        "name": "CMS",
        "description": "",
        "template": "",
        "list": [
            "follow-Zero"
        ]
    },
    "flat-files": {
        "name": "Flat files",
        "description": "",
        "template": "",
        "list": [
            "follow-Zero"
        ]
    }
}