<?php
    echo "flag is here,but you must try to see it.";
    $flag = "swpuctf{xxxxxxxxxx}";
