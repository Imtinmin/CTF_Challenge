<?php
    echo json_encode($msg);
    exit();