<?php 

// 定义项目路径
define('BASE_PATH', __DIR__);
define('BASR_URL', "{$_SERVER['SERVER_NAME']}/demo/Blog");

// 引入核心类
require BASE_PATH . '/Common/config.php';
require BASE_PATH . '/Common/fun.php';
require BASE_PATH . '/Common/Tools.php';
