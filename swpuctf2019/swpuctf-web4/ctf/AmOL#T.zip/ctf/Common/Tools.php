<?php 


class Tools
{
	public static function test()
	{

	}
}

