<?php  
namespace DB;

// 数据库配置信息
define('DB_DSN', 'mysql:dbname=ctf;host=localhost;charset=utf8');
define('DB_USER', 'ctf');
define('DB_PASSWORD', 'swpuctf2019');
define('DB_DATABASE', 'ctf');
define('DB_PORT', '3306');
define('CHARSET', 'utf-8');

// 默认分页大小
define('DEFAULT_PAGE_SIZE', '5');
