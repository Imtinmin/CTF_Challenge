<?php
//0n1y_4_Admin.php
echo 'nctf{fake_flag,guys}';

//nctf{thi3_is_a_rea11y_fl4g}
?>
