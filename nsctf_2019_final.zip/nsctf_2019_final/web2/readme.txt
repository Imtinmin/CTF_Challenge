back.so 为 linux php so库文件，需要在php.ini里加载。
php版本：5.5.9