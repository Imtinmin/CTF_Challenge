<?php
$host = "localhost";
$port = "3306";
$user = "root";
$pwd = "root";
$dbname = "fish";
?>