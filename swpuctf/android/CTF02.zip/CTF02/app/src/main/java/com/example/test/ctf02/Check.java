package com.example.test.ctf02;

/**
 * Created by asus on 2018/11/5.
 */

public class Check {
    public boolean checkPassword(String str){
        char[] pass = str.toCharArray();
        if(pass.length != 12){
            return false;
        }
        else{
            for(int len = 0; len < pass.length; len ++){
                pass[len] = (char)(0xff - len - 100 - pass[len]);
                if(pass[len] != '0'){
                    return false;
                }
                if(len >= 12){
                    return false;
                }
            }
        }
        return true;
    }
}
