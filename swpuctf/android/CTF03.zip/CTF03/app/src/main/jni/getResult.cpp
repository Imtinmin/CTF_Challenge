//
// Created by asus on 2018/12/10.
//

#include "com_example_test_ctf03_JNI.h"
#include "jni.h"
#include<string.h>
#include<stdlib.h>

int First(char *str) {
	int len = sizeof(str);
	for (int i = 0; i < len; i++) {
		str[i] = str[i] * 2 ^ 128;
	}
	return !strcmp(str, "LN^dl");
}


int Second(char *strOne,char *strTwo) {
	int len = sizeof(strTwo);
	for (int i = 0; i < len; i++) {
		strTwo[i] = strOne[i]  ^ strTwo[i];
	}
	return !strcmp(strTwo, " 5-a");
}

int Third(char *strTwo, char *strThree) {
	int len = sizeof(strThree);
	for (int i = 0; i < len; i++) {
		strThree[i] = strTwo[i] ^ strThree[i];
	}
	return !strcmp(strThree, "AFBo}");
}

void Init(char * strOne, char *strTwo, char *strThree,const char *str,int Len){
	int times = 0;
	for (int i = 0; i < Len; i++) {
		if (i % 3 == 0) {
			strOne[i / 3] = str[i];
			times++;
		}
		else if (i % 3 == 1) {
			strTwo[i / 3] = str[i];
		}
		else if (i % 3 == 2) {
			strThree[i / 3] = str[i];
		}
	}
	strOne[times] = '\0';
	strTwo[times] = '\0';
	strThree[times] = '\0';
}

JNIEXPORT jint JNICALL Java_com_example_test_ctf03_JNI_getResult
  (JNIEnv *env, jclass jobj, jstring str2){
    const char* str = env->GetStringUTFChars(str2,NULL);

    int Len = strlen(str);

    if(Len!=15)
        return 0;

    char *One = (char *)malloc(sizeof(char));
    char *Two = (char *)malloc(sizeof(char));
    char *Three = (char *)malloc(sizeof(char));

    Init(One, Two, Three, str, Len);

    if (First(One))
    {
        if (Second(One, Two))
        {
            if (Third(Two, Three))
            {
                return 1;
            }
            else
            {
                return 0;
            }
        }
        return 0;
    }
    return 0;


  }

