package com.example.test.ctf03;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    EditText pwd;
    Button button;
    TextView textView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        init();

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String str = pwd.getText().toString();
                int result = JNI.getResult(str);
                Show(result);
            }
        });
    }

    public void init(){
        pwd = (EditText) findViewById(R.id.pwd);
        button = (Button) findViewById(R.id.button);
        textView = (TextView) findViewById(R.id.result);
    }

    public void Show(int type){
        switch (type){
            case 0:
                textView.setText("Wrong");
                break;
            case 1:
                textView.setText("Great");
                break;
            default:
                break;
        }
    }
}
