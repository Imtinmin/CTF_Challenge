package com.example.test.ctf03;

/**
 * Created by asus on 2018/12/10.
 */

public class JNI {
    static {
        System.loadLibrary("Native");
    }
    public static native int getResult(String str);
}
