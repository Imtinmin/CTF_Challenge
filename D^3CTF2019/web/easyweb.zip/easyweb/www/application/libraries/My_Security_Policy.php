<?php


class My_Security_Policy extends Smarty_Security
{
	public $php_functions = null;
	public $modifiers = array();
}
