<?php
$CONFIG = [
    "dbhost" => "d3ctf-mysql",
    "dbuser" => "root",
    "dbpassword" => "8282600e5379907d01452d14ef1fba52",
    "dbname" => "app"
];