<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* index.html */
class __TwigTemplate_9ebad17ffabba5650490c013dcab9aea391e18d3fa75fe57c2dde73d9cbdadee extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'content' => [$this, 'block_content'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "layout.html";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $this->parent = $this->loadTemplate("layout.html", "index.html", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_content($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 4
        echo "<div class=\"jumbotron\">
    <div class=\"container\">
        <h1>Building...</h1>
        <p>Welcome to ShowHub. ShowHub is a fashion community, which helps people to find the most popular goods, from clothes to cosmetics. We promise all of our goods are imported through the legal ways. Counterfeit or smuggled products are strictly forbidden.</p>
        <p><a class=\"btn btn-primary btn-lg\" role=\"button\"  data-toggle=\"modal\" data-target=\"#showModal\">Learn more &raquo;</a></p>
    </div>
</div>

<!-- Modal -->
<div class=\"modal fade\" id=\"showModal\" tabindex=\"-1\" role=\"dialog\" aria-hidden=\"true\">
    <div class=\"modal-dialog\" role=\"document\">
      <div class=\"modal-content\">
        <div class=\"modal-header\">
          <h5 class=\"modal-title\">What is ShowHub?</h5>
          <button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-label=\"Close\">
            <span aria-hidden=\"true\">&times;</span>
          </button>
        </div>
        <div class=\"modal-body\">
          <p><b>S</b>weet</p>
          <p><b>H</b>onest</p>
          <p><b>O</b>utstanding</p>
          <p><b>W</b>ise</p>
          <p><b>H</b>andsome</p>
          <p><b>U</b>nique</p>
          <p><b>B</b>rilliant</p>
          <h4>ShowHub - For fashion, for you~</h4>
        </div>
        <div class=\"modal-footer\">
          <button type=\"button\" class=\"btn btn-secondary\" data-dismiss=\"modal\">Close</button>
        </div>
      </div>
    </div>
  </div>


<div class=\"container\">
    <div class=\"row\">
        <div class=\"col-md-4\">
            <h2>Boundaries are meant to be pushed</h2>
            <p>ShowHub cooperate with the famous manufacturers all over the world, we discover the distinctive collections created by brilliant designers. </p>
        </div>
        <div class=\"col-md-4\">
            <h2>The best for the best</h2>
            <p>ShowHub is community which defy limits. We employees from all over the world, in order to catch the popular trend right now!</p>
        </div>
        <div class=\"col-md-4\">
            <h2>The ultimate goods for the ultimate people</h2>
            <p>We promise all of our products have passed the state-level test. Counterfeit or smuggled products are strictly forbidden.</p>
        </div>
    </div>

    <hr>

    <footer>
        <p>&copy; Li4n0@D^3CTF 2019.</p>
    </footer>
</div>
";
    }

    public function getTemplateName()
    {
        return "index.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  50 => 4,  46 => 3,  35 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "index.html", "/var/www/html/Templates/index.html");
    }
}
