<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* welcome.html */
class __TwigTemplate_aa8807b0e3633140fa3799f3be6f6fc3cfc8edcabd0ddfa7d29770b2021be900 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'content' => [$this, 'block_content'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "layout.html";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $this->parent = $this->loadTemplate("layout.html", "welcome.html", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_content($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 4
        echo "<div class=\"jumbotron\">
    <div class=\"container\">
        <h1>Welcome ";
        // line 6
        echo twig_escape_filter($this->env, ($context["username"] ?? null), "html", null, true);
        echo "~</h1>
        <h3>ShowHub is building, please wait...</h3>
    </div>
</div>

<div class=\"container\">
    <div class=\"media\">
        <div class=\"media-left\">
            <a href=\"#\">
                <img class=\"media-object\" alt=\"64x64\" src=\"/static/clothes.jpg\" data-holder-rendered=\"true\" style=\"width: 64px; height: 64px;\">
            </a>
        </div>
        <div class=\"media-body\">
            <h4 class=\"media-heading\">Clothes</h4>
            ShowHub pick the most fashion clothes from all over the world. Our employees will choose the best one for you according to your preference.
        </div>
    </div>
    <div class=\"media\">
        <div class=\"media-left\">
            <a href=\"#\">
                <img class=\"media-object\" alt=\"64x64\" src=\"/static/cosmetics.jpg\" data-holder-rendered=\"true\" style=\"width: 64px; height: 64px;\">
            </a>
        </div>
        <div class=\"media-body\">
            <h4 class=\"media-heading\">Cosmetics</h4>
            Sun screen, concealer, shading powder, pressed powder... ShowHub provides the best products to beauty your skin.
        </div>
    </div>
    <div class=\"media\">
        <div class=\"media-left\">
            <a href=\"#\">
                <img class=\"media-object\" data-src=\"holder.js/64x64\" alt=\"64x64\" src=\"/static/arispods_pro.jpg\" data-holder-rendered=\"true\" style=\"width: 64px; height: 64px;\">
            </a>
        </div>
        <div class=\"media-body\">
            <h4 class=\"media-heading\">Electronic products</h4>
            ArisPods Pro, MoeBook Pro, iPhtwo X... ShowHub can get the most fashion electronic products at a very low price. This is because ShowHub cooperates with these company for a long time.
        </div>
    </div>
</div>

";
    }

    public function getTemplateName()
    {
        return "welcome.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  54 => 6,  50 => 4,  46 => 3,  35 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "welcome.html", "/var/www/html/Templates/welcome.html");
    }
}
