<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* layout.html */
class __TwigTemplate_63e959ce146ddae5767b7bcc1569824e964ab39f1ffb8bbf5a3acb5b57c9386a extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
            'content' => [$this, 'block_content'],
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 1
        echo "<!DOCTYPE html>
<html lang=\"zh-CN\">
<head>
    <meta charset=\"utf-8\">
    <meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\">
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">

    <title>ShowHub</title>

    <link href=\"https://cdn.bootcss.com/bootstrap/3.3.7/css/bootstrap.min.css\" rel=\"stylesheet\">
    <script src=\"https://cdn.bootcss.com/jquery/3.4.1/jquery.min.js\"></script>
    <script src=\"https://cdn.bootcss.com/bootstrap/3.3.7/js/bootstrap.min.js\"></script>

</head>

<body>

<nav class=\"navbar navbar-inverse navbar-fixed-top\">
    <div class=\"container\">
        <div class=\"navbar-header\">
            <button type=\"button\" class=\"navbar-toggle collapsed\" data-toggle=\"collapse\" data-target=\"#navbar\"
                    aria-expanded=\"false\" aria-controls=\"navbar\">
                <span class=\"sr-only\">Toggle navigation</span>
                <span class=\"icon-bar\"></span>
                <span class=\"icon-bar\"></span>
                <span class=\"icon-bar\"></span>
            </button>
            <a class=\"navbar-brand\" href=\"/\">ShowHub</a>
        </div>
        <div id=\"navbar\" class=\"navbar-collapse collapse\">
            ";
        // line 31
        if (($context["username"] ?? null)) {
            // line 32
            echo "            <div class=\"collapse navbar-collapse\">
                <ul class=\"nav navbar-nav navbar-right\">
                    <li class=\"nav-item\">
                        <a class=\"navbar-link\" href=\"/Manage/\">Home</a>
                    </li>
                    <li class=\"nav-item\">
                        <a class=\"navbar-link\" href=\"/WebConsole/\">WebConsole</a>
                    </li>
                    <li class=\"nav-item\">
                        <a class=\"navbar-link\" href=\"/Logout/\">Logout</a>
                    </li>
                </ul>
            </div>
            ";
        } else {
            // line 46
            echo "            <form method=\"post\" action=\"/Login/\" class=\"navbar-form navbar-right\">
                <div class=\"form-group\">
                    <input name=\"username\" id=\"Username\" type=\"text\" placeholder=\"Username\" class=\"form-control\">
                </div>
                <div class=\"form-group\">
                    <input name=\"password\" id=\"Password\" type=\"password\" placeholder=\"Password\" class=\"form-control\">
                </div>
                <button id=\"signin\" class=\"btn btn-success\">Sign in</button>
                <button id=\"signup\" class=\"btn btn-success\">Sign up</button>
            </form>
            ";
        }
        // line 57
        echo "        </div>
    </div>
</nav>
";
        // line 60
        if (($context["msg"] ?? null)) {
            // line 61
            echo "<div style=\"margin:48px 0 0 0\" class=\"alert alert-danger\" role=\"alert\">
    ";
            // line 62
            echo twig_escape_filter($this->env, ($context["msg"] ?? null), "html", null, true);
            echo "
</div>
";
        }
        // line 65
        $this->displayBlock('content', $context, $blocks);
        // line 67
        echo "
<script>
    \$(\"#signin\").on(\"click\", function () {
        \$(\"form\")[0].submit()
    })
    \$(\"#signup\").on(\"click\", function () {
        \$(\"form\")[0].action = '/Register'
        console.log(1)
        \$(\"form\")[0].submit()
    })
</script>


</body>
</html>";
    }

    // line 65
    public function block_content($context, array $blocks = [])
    {
        $macros = $this->macros;
    }

    public function getTemplateName()
    {
        return "layout.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  137 => 65,  119 => 67,  117 => 65,  111 => 62,  108 => 61,  106 => 60,  101 => 57,  88 => 46,  72 => 32,  70 => 31,  38 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "layout.html", "/var/www/html/Templates/layout.html");
    }
}
