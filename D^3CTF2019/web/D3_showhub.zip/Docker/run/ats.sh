#! /bin/sh
chmod -R 777 /opt/ts-v2/etc/trafficserver/
/opt/ts-v2/bin/trafficserver start
while true;
do
	echo 1
	sleep 5
done
