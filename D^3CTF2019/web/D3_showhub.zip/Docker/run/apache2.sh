#! /bin/bash
service apache2 start
while true;
do
	echo 1;
	sleep 5;
done
